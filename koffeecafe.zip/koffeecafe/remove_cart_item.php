<?php
session_start();

if (isset($_GET['id'])) {
    $prod_id = $_GET['id'];
    
    // Remove the specific item from the session cart
    if (isset($_SESSION['cart'][$prod_id])) {
        unset($_SESSION['cart'][$prod_id]);
    }
}

// Redirect back to checkout
header("Location: checkout.php");
exit();
?>