<?php 
session_start(); 
include 'db_connect.php';

// Calculate cart data for the header
$cart_count = 0;
if (isset($_SESSION['cart'])) {
    $cart_count = array_sum($_SESSION['cart']);
}
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Koffee Cafe">
    <meta name="keywords" content="Cafe, Coffee, Steak, Pasta, Dessert">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Koffee | Home</title>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/barfiller.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__inner">
                           <div class="header__top__left">
                                <?php if(isset($_SESSION['user_name'])): ?>
                                    <span style="color: #111; font-weight: 600;">
                                        <?php echo ($_SESSION['role'] == 'employee') ? "Staff: " : "Welcome, "; ?>
                                        <?php echo $_SESSION['user_name']; ?>
                                    </span>
                                    <a href="logout.php" style="margin-left: 15px; color: #f08632;">Logout</a>
                                <?php else: ?>
                                    <a href="login.php" style="color: #111; font-weight: 600;">Sign in</a>
                                <?php endif; ?>
                            </div>
                            
                            <div class="header__logo">
                                <a href="index.php"><img src="img/logo-cafe.png" alt="Koffee Logo"></a>
                            </div>
                            
                            <div class="header__top__right">
								<?php if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee'): ?>
									<div class="header__top__right__cart">
										<?php 
											// Determine where the cart link should go
											$cart_link = isset($_SESSION['user_id']) ? "checkout.php" : "login.php";
										?>
										<a href="<?php echo $cart_link; ?>" 
										   onclick="<?php if(!isset($_SESSION['user_id'])) echo "alert('Please login to view your cart');"; ?>">
											<img src="img/icon/cart.png" alt=""> 
											<span><?php echo $cart_count; ?></span>
										</a>
										<div class="cart__price">Items: <span><?php echo $cart_count; ?></span></div>
									</div>
								<?php endif; ?>
							</div>
                        </div>
                    </div>
                </div>
                <div class="canvas__open"><i class="fa fa-bars"></i></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="header__menu mobile-menu">
                        <ul>
                            <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'employee'): ?>
                                <li><a href="admin_dashboard.php">Manage Orders</a></li>
                                <li><a href="manage_menu.php">Manage Menu</a></li>
                                <li><a href="menu.php">Preview Menu</a></li>
                            <?php else: ?>
                                <li class="active"><a href="index.php">Home</a></li>
                                <li><a href="about.php">About</a></li>
                                <li><a href="menu.php">Menu</a></li>
                                <?php if(isset($_SESSION['user_id'])): ?>
                                    <li><a href="my_orders.php">My Orders</a></li>
                                <?php endif; ?>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <section class="about spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="about__text">
                        <div class="section-title">
                            <span>Welcome to Koffee</span>
                            <h2>More Than Just Your Average Coffee Shop</h2>
                        </div>
                        <p>At Koffee, we believe in serving high-quality comfort food paired with the perfect brew. Whether you are looking for a morning pick-me-up or a hearty dinner, our kitchen is ready to serve.</p>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <ul style="list-style: none; padding: 0;">
                                    <li><i class="fa fa-check-circle" style="color: #f08632;"></i> Premium Coffee & Drinks</li>
                                    <li><i class="fa fa-check-circle" style="color: #f08632;"></i> Sizzling Steaks & Burgers</li>
                                </ul>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <ul style="list-style: none; padding: 0;">
                                    <li><i class="fa fa-check-circle" style="color: #f08632;"></i> Pastas & Fried Rice</li>
                                    <li><i class="fa fa-check-circle" style="color: #f08632;"></i> Varieties of Desserts</li>
                                </ul>
                            </div>
                        </div>
                        <a href="about.php" class="primary-btn" style="margin-top: 20px;">Learn More About Us</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about__pic">
                        <img src="img/KoffeeCafe.png" alt="Our Cafe Atmosphere" style="width: 70%; border-radius: 5px; box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
                    </div>
                </div>
            </div>
        </div>
    </section>
	
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.barfiller.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>