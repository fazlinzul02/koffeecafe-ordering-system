<?php
session_start(); 
include 'db_connect.php';

// Calculate cart data for the header
$cart_count = 0;
$cart_total = 0;

if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $cart_count = array_sum($_SESSION['cart']);
    foreach ($_SESSION['cart'] as $id => $qty) {
        $res = $conn->query("SELECT ProdPrice FROM product WHERE ProdID = $id");
        if ($row = $res->fetch_assoc()) {
            $cart_total += ($row['ProdPrice'] * $qty);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Koffee Cafe">
    <meta name="keywords" content="Coffee, Food, Dessert">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Koffee | About Us</title>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/barfiller.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__cart">
            <div class="offcanvas__cart__item">
                <a href="checkout.php"><img src="img/icon/cart.png" alt=""> <span><?php echo $cart_count; ?></span></a>
                <div class="cart__price">Cart: <span>RM <?php echo number_format($cart_total, 2); ?></span></div>
            </div>
        </div>
        <div class="offcanvas__logo">
            <a href="index.php"><img src="img/logo-cafe.png" alt=""></a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <div class="offcanvas__option">
            <?php if(isset($_SESSION['user_name'])): ?>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.html">Sign in</a>
            <?php endif; ?>
        </div>
    </div>

    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__inner">
                            <div class="header__top__left">
                                <?php if(isset($_SESSION['user_name'])): ?>
                                    <span style="color: #111; font-weight: 600;">
                                        <?php echo ($_SESSION['role'] == 'employee') ? "Staff: " : "Welcome, "; ?>
                                        <?php echo $_SESSION['user_name']; ?>
                                    </span>
                                    <a href="logout.php" style="margin-left: 15px; color: #f08632;">Logout</a>
                                <?php else: ?>
                                    <a href="login.php" style="color: #111; font-weight: 600;">Sign in</a>
                                <?php endif; ?> 
                            </div>
                            <div class="header__logo">
                                <a href="index.php"><img src="img/logo-cafe.png" alt="Koffee Logo"></a>
                            </div>
                            <div class="header__top__right">
                                <?php if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee'): ?>
                                    <div class="header__top__right__cart">
                                        <a href="checkout.php">
                                            <img src="img/icon/cart.png" alt=""> 
                                            <span><?php echo $cart_count; ?></span>
                                        </a>
                                        <div class="cart__price">Items: <span><?php echo $cart_count; ?></span></div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="canvas__open"><i class="fa fa-bars"></i></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="header__menu mobile-menu">
                        <ul>
                            <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'employee'): ?>
                                <li><a href="admin_dashboard.php">Manage Orders</a></li>
                                <li><a href="manage_menu.php">Manage Menu</a></li>
                                <li><a href="menu.php">Preview Menu</a></li>
                                <li class="active"><a href="about.php">About</a></li>
                            <?php else: ?>
                                <li><a href="index.php">Home</a></li>
                                <li class="active"><a href="about.php">About</a></li>
                                <li><a href="menu.php">Menu</a></li>
                                <?php if(isset($_SESSION['user_id'])): ?>
                                    <li><a href="my_orders.php">My Orders</a></li>
                                <?php endif; ?>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <section class="about spad">
        <div class="container"> 
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="about__text">
                        <div class="section-title">
                            <h2>Great Food, Better Coffee, Best Memories</h2>
                        </div>
                        <p>
                        Koffee is more than just a destination for caffeine lovers; it’s a culinary hub where flavors come alive. From the sizzle of our <strong>signature steaks</strong> and <strong>gourmet burgers</strong> to the comforting aroma of our <strong>handcrafted pastas</strong> and <strong>classic fried rice</strong>, we pride ourselves on serving hearty, hot meals that satisfy every craving.
                        </p>
                        <p>
                        Complement your meal with our expertly brewed drinks or indulge in our wide variety of <strong>premium desserts</strong>. Whether you're here for a quick lunch or a long dinner, Koffee offers a cozy atmosphere where quality ingredients meet passion-driven cooking.
                        </p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="about__bar">
                        <div class="about__bar__item">
                            <p>Specialty Coffee & Drinks</p>
                            <div id="bar1" class="barfiller">
                                <div class="tipWrap"><span class="tip"></span></div>
                                <span class="fill" data-percentage="95"></span>
                            </div>
                        </div>
                        <div class="about__bar__item">
                            <p>Hot Meals (Steaks & Pasta)</p>
                            <div id="bar2" class="barfiller">
                                <div class="tipWrap"><span class="tip"></span></div>
                                <span class="fill" data-percentage="90"></span>
                            </div>
                        </div>
                        <div class="about__bar__item">
                            <p>Artisan Desserts</p>
                            <div id="bar3" class="barfiller">
                                <div class="tipWrap"><span class="tip"></span></div>
                                <span class="fill" data-percentage="85"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<script src="js/jquery-3.3.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.nice-select.min.js"></script>
<script src="js/jquery.barfiller.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/jquery.slicknav.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.nicescroll.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>