<?php
session_start();
include 'db_connect.php';

if (isset($_POST['add_product'])) {
    $name = mysqli_real_escape_string($conn, $_POST['ProdName']);
    $price = $_POST['ProdPrice'];
    $qty = $_POST['ProdQty'];
    $empId = $_SESSION['emp_id']; // The employee currently logged in

    $sql = "INSERT INTO product (ProdName, ProdPrice, ProdQty, EmpID) 
            VALUES ('$name', '$price', '$qty', '$empId')";

    if ($conn->query($sql)) {
        header("Location: manage_menu.php?success=1");
    } else {
        echo "Error: " . $conn->error;
    }
}
?>