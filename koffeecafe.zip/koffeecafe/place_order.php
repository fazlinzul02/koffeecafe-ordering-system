<?php
session_start();
include 'db_connect.php';

// Set timezone to Malaysia
date_default_timezone_set('Asia/Kuala_Lumpur');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Basic Security: Check if user is logged in and cart is not empty
    if (!isset($_SESSION['user_id'])) {
        echo "<script>alert('Please login to place an order.'); window.location.href='login.html';</script>";
        exit();
    }

    if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        echo "<script>alert('Your cart is empty!'); window.location.href='menu.php';</script>";
        exit();
    }

    $cust_id = $_SESSION['user_id'];
    $total_amount = $_POST['total_amount'];
    $payment_method = $_POST['payment_method'];
    $notes = mysqli_real_escape_string($conn, $_POST['notes']);
    
    // Captured using Malaysia Timezone set above
    $order_date = date('Y-m-d H:i:s');

    // 1. Create the Order
    $sql_order = "INSERT INTO `orders` (CustID, OrderDate, TotalAmount, OrderStatus, PaymentMethod, Notes) 
                  VALUES ('$cust_id', '$order_date', '$total_amount', 'Pending', '$payment_method', '$notes')";

    if ($conn->query($sql_order)) {
        $order_id = $conn->insert_id; // Get the ID of the order we just created

        // 2. Loop through cart items to save them and update inventory
        foreach ($_SESSION['cart'] as $prod_id => $qty) {
            
            // Get product price again for safety
            $res = $conn->query("SELECT ProdPrice FROM product WHERE ProdID = '$prod_id'");
            if ($p_row = $res->fetch_assoc()) {
                $price = $p_row['ProdPrice'];

                // Save to order_items
                $conn->query("INSERT INTO order_items (OrderID, ProdID, Quantity, Price) 
                              VALUES ('$order_id', '$prod_id', '$qty', '$price')");

                // SUBTRACT FROM INVENTORY
                $conn->query("UPDATE product SET ProdQty = ProdQty - $qty WHERE ProdID = '$prod_id'");
            }
        }

        // 3. Clear cart and redirect
        unset($_SESSION['cart']);
        echo "<script>alert('Order placed successfully!'); window.location.href='my_orders.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>