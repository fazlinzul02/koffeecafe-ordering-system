<?php 
session_start(); 
include 'db_connect.php';

// Fetch products from database
$query = "SELECT * FROM product WHERE ProdQty > 0"; 
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Koffee | Menu</title>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

    <style>
        .product__item:hover .product__item__text {
            opacity: 1 !important;
            visibility: visible !important;
            bottom: 0 !important;
        }
        
        .product__item__text .product__item__price {
            color: #111111 !important;
            display: block !important;
            font-weight: 700;
        }

        .staff-name-link {
            color: #111 !important;
            font-weight: 600 !important;
        }

        .edit-btn {
            background-color: #111;
            color: #fff !important;
            padding: 8px 15px;
            border-radius: 5px;
            font-size: 12px;
            text-transform: uppercase;
            font-weight: 700;
            display: inline-block;
            margin-top: 10px;
        }
        .edit-btn:hover {
            color: #f08632 !important;
            text-decoration: none;
        }
    </style>
</head>

<body>
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__inner">
                            <div class="header__top__left">
                                <?php if(isset($_SESSION['user_name'])): ?>
                                    <span style="color: #111; font-weight: 600;">
                                        <?php 
                                            if($_SESSION['role'] == 'employee') {
                                                echo "Staff: " . $_SESSION['user_name']; 
                                            } else {
                                                echo "Welcome, " . $_SESSION['user_name']; 
                                            }
                                        ?>
                                    </span>
                                    <a href="logout.php" style="margin-left: 15px; color: #f08632;">Logout</a>
                                <?php else: ?>
                                    <a href="login.php" style="color: #111; font-weight: 600;">Sign in</a>
                                <?php endif; ?> 
                            </div>
                            
                            <div class="header__logo">
                                <a href="index.php"><img src="img/logo-cafe.png" alt="Koffee Logo"></a>
                            </div>

                            <div class="header__top__right">
                                <?php if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee'): ?>
                                    <div class="header__top__right__cart">
                                        <?php 
                                            $cart_count = (isset($_SESSION['cart'])) ? array_sum($_SESSION['cart']) : 0;
                                            
                                            // LOGIC: If not logged in, clicking cart sends them to login
                                            $cart_link = isset($_SESSION['user_id']) ? "checkout.php" : "login.php";
                                        ?>
                                        <a href="<?php echo $cart_link; ?>" onclick="<?php if(!isset($_SESSION['user_id'])) echo "alert('Please login to view your cart and checkout');"; ?>">
                                            <img src="img/icon/cart.png" alt=""> 
                                            <span><?php echo $cart_count; ?></span>
                                        </a>
                                        <div class="cart__price">Items: <span><?php echo $cart_count; ?></span></div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="header__menu mobile-menu">
                        <ul>
                            <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'employee'): ?>
                                <li><a href="admin_dashboard.php">Manage Orders</a></li>
                                <li><a href="manage_menu.php">Manage Menu</a></li>
                                <li class="active"><a href="menu.php">Preview Menu</a></li>
                            <?php else: ?>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About</a></li>
                                <li class="active"><a href="menu.php">Menu</a></li>
                                <?php if(isset($_SESSION['user_id'])): ?>
                                    <li><a href="my_orders.php">My Orders</a></li>
                                <?php endif; ?>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <section class="shop spad">
        <div class="container">
            <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'employee'): ?>
                <div class="section-title text-left">
                    <span>Staff View</span>
                    <h2>Menu Preview</h2>
                </div>
            <?php else: ?>
                <div class="section-title text-left">
                    <span>Delicious Selection</span>
                    <h2>Our Menu</h2>
                </div>
            <?php endif; ?>

            <div class="shop__option">
                <div class="row">
                    <div class="col-lg-7 col-md-7">
                        <div class="shop__option__search">
                            <select id="categoryFilter" onchange="filterCategory()">
                                <option value="all_category">All Categories</option>
                                <option value="Meals">Meals</option>
                                <option value="Drinks">Drinks</option>
                                <option value="Desserts">Desserts</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row" id="product-container">
                <?php 
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) { 
                        $category = $row['Category'] ?? "Meals"; 
                        $image = (!empty($row['ProdImage'])) ? $row['ProdImage'] : "default.jpg";
                ?>
                    <div class="col-lg-3 col-md-6 col-sm-6 product-item" data-category="<?php echo $category; ?>">
                        <div class="product__item">
                            <div class="product__item__pic set-bg" data-setbg="img/shop/<?php echo $image; ?>">
                                <div class="product__label">
                                    <span><?php echo $category; ?></span>
                                </div>
                            </div>
                            <div class="product__item__text">
                                <h6 style="font-weight: 600;"><?php echo $row['ProdName']; ?></h6>
                                <div class="product__item__price">RM<?php echo number_format($row['ProdPrice'], 2); ?></div>
                                
                                <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'employee'): ?>
                                    <a href="edit_product.php?id=<?php echo $row['ProdID']; ?>" class="edit-btn">Edit Item</a>
                                <?php else: ?>
                                    <form action="cart_process.php" method="POST">
                                        <input type="hidden" name="prod_id" value="<?php echo $row['ProdID']; ?>">
                                        <button type="submit" name="add_to_cart" class="primary-btn" style="border:none; margin-top:10px;">Add to Cart</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php 
                    } 
                }
                ?>
            </div>
        </div>
    </section>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/main.js"></script>

    <script>
    function filterCategory() {
        var selectedCategory = document.getElementById("categoryFilter").value;
        var products = document.getElementsByClassName("product-item");
        for (var i = 0; i < products.length; i++) {
            var productCategory = products[i].getAttribute("data-category");
            products[i].style.display = (selectedCategory === "all_category" || productCategory === selectedCategory) ? "block" : "none";
        }
    }
    </script>
</body>
</html>