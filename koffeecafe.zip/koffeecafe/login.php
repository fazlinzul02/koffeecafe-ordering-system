<?php session_start(); ?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Koffee | Login</title>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__inner">
                            <div class="header__top__left">
                                <a href="login.php" style="color: #111; font-weight: 600;">Sign in</a> 
                            </div>
                            <div class="header__logo">
                                <a href="./index.php"><img src="img/logo-cafe.png" alt="Koffee Logo"></a>
                            </div>
                            <div class="header__top__right">
                                <?php if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee'): ?>
                                    <div class="header__top__right__cart">
                                        <?php 
                                            $cart_count = (isset($_SESSION['cart'])) ? array_sum($_SESSION['cart']) : 0;
                                            $cart_link = isset($_SESSION['user_id']) ? "checkout.php" : "login.php";
                                        ?>
                                        <a href="<?php echo $cart_link; ?>" onclick="<?php if(!isset($_SESSION['user_id'])) echo "alert('Please login to view your cart and checkout');"; ?>">
                                            <img src="img/icon/cart.png" alt=""> 
                                            <span><?php echo $cart_count; ?></span>
                                        </a>
                                        <div class="cart__price">Items: <span><?php echo $cart_count; ?></span></div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="canvas__open"><i class="fa fa-bars"></i></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="header__menu mobile-menu">
                        <ul>
                            <li><a href="./index.php">Home</a></li>
                            <li><a href="./about.php">About</a></li>
                            <li><a href="./menu.php">Menu</a></li>
                            </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <section class="login spad">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-6">
                    <div class="contact__form">
                        <div class="section-title text-center">
                            <span>Welcome Back</span>
                            <h2>Login</h2>
                        </div>
                        
                        <form action="auth.php" method="POST">
                            <div class="row">
                                <div class="col-lg-12">
                                    <input type="email" name="CustEmail" placeholder="Email Address" required>
                                </div>
                                <div class="col-lg-12">
                                    <input type="password" name="CustPassword" placeholder="Password" required>
                                </div>
                                <div class="col-lg-12 text-center">
                                    <button type="submit" name="login" class="site-btn">Login Now</button>
                                </div>
                            </div>
                        </form>

                        <div class="blog__details__btns" style="border: none; padding: 0; margin-top: 30px;">
                            <div class="row">
                                <div class="col-lg-12 text-center">
                                    <a href="#" style="color: #111111; font-weight: 600;">Forgot Password?</a>
                                    <p style="margin-top: 15px;">Don't have an account? <a href="register.php" style="color: #f08632;">Register Now</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>