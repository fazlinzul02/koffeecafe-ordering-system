<?php
session_start();
include 'db_connect.php';

if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['CustEmail']);
    $password = mysqli_real_escape_string($conn, $_POST['CustPassword']);

    // 1. Try to find a Customer first
    $cust_query = "SELECT * FROM customer WHERE CustEmail = '$email' AND CustPassword = '$password'";
    $cust_result = $conn->query($cust_query);

    if ($cust_result->num_rows > 0) {
        $user = $cust_result->fetch_assoc();
        $_SESSION['user_id'] = $user['CustID'];
        $_SESSION['user_name'] = $user['CustName'];
        $_SESSION['role'] = 'customer';
        header("Location: index.php");
        exit();
    } 
    
    // 2. If not a customer, try to find an Employee
    $emp_query = "SELECT * FROM employees WHERE EmpEmail = '$email' AND EmpPassword = '$password'";
    $emp_result = $conn->query($emp_query);

    if ($emp_result->num_rows > 0) {
        $emp = $emp_result->fetch_assoc();
        $_SESSION['user_id'] = $emp['EmpID'];
        $_SESSION['user_name'] = $emp['EmpName'];
        $_SESSION['role'] = 'employee';
        // Send employees to a different dashboard page
        header("Location: admin_dashboard.php");
        exit();
    } else {
        // FAIL: Neither customer nor employee
        echo "<script>
                alert('Account not found. Please check your credentials.');
                window.location.href='login.php';
              </script>";
        exit();
    }
}
?>