<?php
session_start();
include 'db_connect.php';

if (isset($_POST['add_to_cart'])) {
    $prod_id = $_POST['prod_id'];
    $quantity = 1; // Default to 1 for now

    // Initialize cart if it doesn't exist
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    // Check if product is already in cart, if so, increase quantity
    if (isset($_SESSION['cart'][$prod_id])) {
        $_SESSION['cart'][$prod_id] += $quantity;
    } else {
        $_SESSION['cart'][$prod_id] = $quantity;
    }

    // Redirect back to menu with a success message
    header("Location: menu.php?action=added");
    exit();
}
?>