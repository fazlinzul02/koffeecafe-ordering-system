<?php
session_start();
include 'db_connect.php';

// Security check: Only employees can delete/cancel orders
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.html");
    exit();
}

if (isset($_GET['id'])) {
    $order_id = mysqli_real_escape_string($conn, $_GET['id']);

    // 1. Fetch order items before deleting the order to RESTORE inventory
    $item_sql = "SELECT ProdID, Quantity FROM order_items WHERE OrderID = '$order_id'";
    $item_result = $conn->query($item_sql);

    if ($item_result && $item_result->num_rows > 0) {
        while ($item = $item_result->fetch_assoc()) {
            $p_id = $item['ProdID'];
            $qty = $item['Quantity'];

            // 2. Add the quantity back to the product table
            $update_inventory = "UPDATE product SET ProdQty = ProdQty + $qty WHERE ProdID = '$p_id'";
            $conn->query($update_inventory);
        }
    }

    // 3. Delete the order (Foreign Key CASCADE will delete from order_items automatically)
    $sql = "DELETE FROM `orders` WHERE OrderID = '$order_id'";

    if ($conn->query($sql)) {
        echo "<script>
                alert('Order #$order_id has been cancelled and items returned to inventory.');
                window.location.href='admin_dashboard.php';
              </script>";
    } else {
        echo "<script>
                alert('Error deleting order: " . $conn->error . "');
                window.location.href='admin_dashboard.php';
              </script>";
    }
} else {
    header("Location: admin_dashboard.php");
}

$conn->close();
?>