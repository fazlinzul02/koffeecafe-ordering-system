<?php
session_start();
include 'db_connect.php';

if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $status = mysqli_real_escape_string($conn, $_GET['status']);

    $sql = "UPDATE `orders` SET OrderStatus = '$status' WHERE OrderID = '$id'";

    if ($conn->query($sql)) {
        header("Location: admin_dashboard.php");
    } else {
        echo "Error updating order: " . $conn->error;
    }
}
?>