<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.html");
    exit();
}

// 1. Fetch current data
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $res = $conn->query("SELECT * FROM product WHERE ProdID = '$id'");
    $product = $res->fetch_assoc();
}

// 2. Handle Update
// 2. Handle Update
if (isset($_POST['update_product'])) {
    $id = $_POST['ProdID'];
    $name = mysqli_real_escape_string($conn, $_POST['ProdName']);
    $price = $_POST['ProdPrice'];
    $qty = $_POST['ProdQty'];
    $category = $_POST['Category'];
    
    // FIX 1: Define the variable by getting it from the session
    $emp_id = $_SESSION['user_id']; 

    // Image logic
    if (!empty($_FILES['ProdImage']['name'])) {
        $image = $_FILES['ProdImage']['name'];
        move_uploaded_file($_FILES['ProdImage']['tmp_name'], "img/shop/" . $image);
        $img_query = ", ProdImage = '$image'";
    } else {
        $img_query = ""; 
    }

    // FIX 2: Use the variable in the query
    $sql = "UPDATE product SET 
            ProdName = '$name', 
            ProdPrice = '$price', 
            ProdQty = '$qty', 
            Category = '$category',
            EmpID = '$emp_id' 
            $img_query 
            WHERE ProdID = '$id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Product Updated!'); window.location.href='manage_menu.php';</script>";
    } else {
        // This will help you catch errors in the future
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="zxx">
<head>
    <title>Koffee Admin | Edit Product</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <style>
        .admin-card { background: #fff; padding: 40px; border-radius: 10px; box-shadow: 0 5px 25px rgba(0,0,0,0.05); max-width: 600px; margin: 50px auto; }
        .primary-btn { border: none; width: 100%; margin-top: 20px; cursor: pointer; }
        .current-img { width: 100px; margin-bottom: 10px; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="admin-card">
            <div class="section-title"><h2>Edit Product</h2></div>
            <form action="edit_product.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="ProdID" value="<?php echo $product['ProdID']; ?>">
                
                <div class="form-group">
                    <label>Product Name</label>
                    <input type="text" name="ProdName" class="form-control" value="<?php echo $product['ProdName']; ?>" required>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Price (RM)</label>
                            <input type="number" step="0.01" name="ProdPrice" class="form-control" value="<?php echo $product['ProdPrice']; ?>" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Stock</label>
                            <input type="number" name="ProdQty" class="form-control" value="<?php echo $product['ProdQty']; ?>" required>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label>Category</label>
                    <select name="Category" class="form-control">
                        <option value="Meals" <?php if($product['Category'] == 'Meals') echo 'selected'; ?>>Meals</option>
                        <option value="Drinks" <?php if($product['Category'] == 'Drinks') echo 'selected'; ?>>Drinks</option>
                        <option value="Desserts" <?php if($product['Category'] == 'Desserts') echo 'selected'; ?>>Desserts</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Change Image (Leave blank to keep current)</label><br>
                    <img src="img/shop/<?php echo $product['ProdImage']; ?>" class="current-img"><br>
                    <input type="file" name="ProdImage" class="form-control-file">
                </div>

                <button type="submit" name="update_product" class="primary-btn">Update Product</button>
                <a href="manage_menu.php" class="btn btn-link btn-block mt-2">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>