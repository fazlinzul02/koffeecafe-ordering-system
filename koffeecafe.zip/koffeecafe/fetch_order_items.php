<?php
include 'db_connect.php';

// Change 'id' to 'order_id' to match your AJAX data key
if(isset($_GET['order_id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['order_id']);
    
    $sql = "SELECT p.ProdName, oi.Quantity, oi.Price 
            FROM order_items oi 
            JOIN product p ON oi.ProdID = p.ProdID 
            WHERE oi.OrderID = '$id'";
    
    $result = $conn->query($sql);

    if($result && $result->num_rows > 0) {
        echo "<table class='table table-sm'>";
        echo "<thead><tr><th>Product</th><th>Qty</th><th>Subtotal</th></tr></thead><tbody>";
        while($row = $result->fetch_assoc()) {
            $subtotal = $row['Quantity'] * $row['Price'];
            echo "<tr>
                    <td>{$row['ProdName']}</td>
                    <td>{$row['Quantity']}</td>
                    <td>RM ".number_format($subtotal, 2)."</td>
                  </tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<p class='text-danger'>No items found for this order.</p>";
    }
} else {
    echo "<p class='text-danger'>Error: No Order ID provided.</p>";
}
?>