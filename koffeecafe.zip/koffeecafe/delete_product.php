<?php
session_start();
include 'db_connect.php';

// Security check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    exit("Access Denied");
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Optional: Get image name to delete file from folder too
    $res = $conn->query("SELECT ProdImage FROM product WHERE ProdID = '$id'");
    $row = $res->fetch_assoc();
    if($row['ProdImage'] != 'default.jpg') {
        unlink("img/shop/" . $row['ProdImage']); // Deletes image file
    }

    $sql = "DELETE FROM product WHERE ProdID = '$id'";
    
    if ($conn->query($sql) === TRUE) {
        header("Location: manage_menu.php?msg=deleted");
    } else {
        echo "Error: " . $conn->error;
    }
}
?>