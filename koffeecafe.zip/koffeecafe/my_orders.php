<?php
session_start();
include 'db_connect.php';

// Set timezone to Malaysia for consistent display
date_default_timezone_set('Asia/Kuala_Lumpur');

// Security check: Only logged-in customers allowed
if (!isset($_SESSION['user_id']) || (isset($_SESSION['role']) && $_SESSION['role'] == 'employee')) {
    header("Location: login.html");
    exit();
}

$cust_id = $_SESSION['user_id'];

// SQL: Fetch orders for this customer
$sql = "SELECT OrderID, OrderDate, TotalAmount, OrderStatus, PaymentMethod 
        FROM `orders` 
        WHERE CustID = '$cust_id' 
        ORDER BY OrderID DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Koffee | My Orders</title>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

    <style>
        .order-table-card {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.05);
        }
        .table thead th {
            background-color: #f08632;
            color: white;
            border: none;
            font-family: "Montserrat", sans-serif;
            font-size: 14px;
            text-transform: uppercase;
        }
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
        }
        /* Design Fix: Ensure colors match for your statuses */
        .status-Pending { background: #fff4e6; color: #f08632; }
        .status-Completed { background: #e7f9ee; color: #28a745; }
        .status-Cancelled { background: #ffebeb; color: #dc3545; }
    </style>
</head>

<body>
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__inner">
                            <div class="header__top__left">
                                <span style="color: #111; font-weight: 600;">Welcome, <?php echo $_SESSION['user_name']; ?></span>
                                <a href="logout.php" style="margin-left: 15px; color: #f08632;">Logout</a>
                            </div>
                            <div class="header__logo">
                                <a href="index.php"><img src="img/logo-cafe.png" alt="Koffee Logo"></a>
                            </div>
                            <div class="header__top__right">
                                <div class="header__top__right__cart">
                                    <?php 
                                        $cart_count = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
                                    ?>
                                    <a href="checkout.php"><img src="img/icon/cart.png" alt=""> <span><?php echo $cart_count; ?></span></a>
                                    <div class="cart__price">Items: <span><?php echo $cart_count; ?></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="canvas__open"><i class="fa fa-bars"></i></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="header__menu mobile-menu">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about.php">About</a></li>
                            <li><a href="menu.php">Menu</a></li>
                            <li class="active"><a href="my_orders.php">My Orders</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <section class="spad">
        <div class="container">
            <div class="section-title text-left">
                <span>Customer Portal</span>
                <h2>My Order History</h2>
            </div>

            <div class="order-table-card">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Date & Time</th>
                                <th>Payment</th>
                                <th>Total Amount</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result && $result->num_rows > 0): ?>
                                <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><strong>#<?php echo $row['OrderID']; ?></strong></td>
                                    <td><?php echo date('d M Y, h:i A', strtotime($row['OrderDate'])); ?></td>
                                    <td><?php echo $row['PaymentMethod']; ?></td>
                                    <td>RM <?php echo number_format($row['TotalAmount'], 2); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $row['OrderStatus']; ?>">
                                            <?php echo $row['OrderStatus']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-dark btn-sm" style="font-size: 11px; font-weight: 700;" 
                                                onclick="viewOrder(<?php echo $row['OrderID']; ?>)">
                                            VIEW ITEMS
                                        </button>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="text-center">You haven't placed any orders yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

    <div class="modal fade" id="orderModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header" style="background: #111; color: #fff;">
                    <h5 class="modal-title" style="font-family: 'Playfair Display', serif;">Order Items</h5>
                    <button type="button" class="close" data-dismiss="modal" style="color: #fff;"><span>&times;</span></button>
                </div>
                <div class="modal-body" id="modalBody">
                    <p class="text-center">Loading...</p>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
    function viewOrder(id) {
        $('#orderModal').modal('show');
        $.ajax({
            url: 'fetch_order_items.php', 
            method: 'GET',
            data: { order_id: id },
            success: function(data) {
                $('#modalBody').html(data);
            },
            error: function() {
                $('#modalBody').html('<p class="text-danger">Failed to load items. Please try again.</p>');
            }
        });
    }
    </script>
</body>
</html>