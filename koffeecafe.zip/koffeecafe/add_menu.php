<?php
include 'db_connect.php';

if(isset($_POST['add_product'])) {
    $name = $_POST['ProdName'];
    $price = $_POST['ProdPrice'];
    $qty = $_POST['ProdQty'];
    $empId = $_SESSION['emp_id']; // Track which employee added it

    $sql = "INSERT INTO product (ProdName, ProdPrice, ProdQty, EmpID) 
            VALUES ('$name', '$price', '$qty', '$empId')";
    
    if ($conn->query($sql) === TRUE) {
        header("Location: manage_menu.php?success=1");
    }
}
?>