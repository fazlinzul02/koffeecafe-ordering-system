<?php
session_start();
include 'db_connect.php';

// Security check: Only employees allowed
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.html");
    exit();
}

// Fetch all products
$sql = "SELECT * FROM product ORDER BY ProdID DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Koffee Admin | Manage Menu</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <style>
        .admin-card {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.05);
            margin-bottom: 50px;
        }
        .table thead th {
            background-color: #f08632;
            color: white;
            border: none;
        }
        .add-btn {
            background-color: #111;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            float: right;
            margin-bottom: 20px;
        }
        .add-btn:hover { color: #f08632; }
    </style>
</head>

<body>
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__inner">
                            <div class="header__top__left">
                                <span style="color: #111; font-weight: 600;">Staff: <?php echo $_SESSION['user_name']; ?></span>
                                <a href="logout.php" style="margin-left: 15px; color: #f08632;">Logout</a>
                            </div>
                            <div class="header__logo">
                                <a href="index.php"><img src="img/logo-cafe.png" alt="Koffee Logo"></a>
                            </div>
                            <div class="header__top__right"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="header__menu mobile-menu">
                        <ul>
                             <?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'employee'): ?>
                                <li><a href="admin_dashboard.php">Manage Orders</a></li>
                                <li class="active"><a href="manage_menu.php">Manage Menu</a></li>
                                <li><a href="menu.php">Preview Menu</a></li>
                            <?php else: ?>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.html">About</a></li>
                                <li><a href="menu.php">Menu</a></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <section class="spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title text-left">
                        <span>Inventory Management</span>
                        <h2>Cafe Menu Items</h2>
                        <a href="add_product.php" class="add-btn"><i class="fa fa-plus"></i> Add New Product</a>
                    </div>
                    
                    <div class="admin-card">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Product Name</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Stock Qty</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($result && $result->num_rows > 0): ?>
                                        <?php while($row = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td><strong>P<?php echo str_pad($row['ProdID'], 2, "0", STR_PAD_LEFT); ?></strong></td>
                                            <td><?php echo $row['ProdName']; ?></td>
                                            <td><?php echo isset($row['Category']) ? $row['Category'] : 'General'; ?></td>
                                            <td>RM<?php echo number_format($row['ProdPrice'], 2); ?></td>
                                            <td><?php echo $row['ProdQty']; ?></td>
                                            <td>
                                                <a href="edit_product.php?id=<?php echo $row['ProdID']; ?>" class="btn btn-primary btn-sm">Edit</a>
                                                <a href="delete_product.php?id=<?php echo $row['ProdID']; ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Delete this product from menu?')">Delete</a>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="6" class="text-center">No products found in menu.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>