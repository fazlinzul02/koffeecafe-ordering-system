<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.html");
    exit();
}

if (isset($_POST['save_product'])) {
    $name = mysqli_real_escape_string($conn, $_POST['ProdName']);
    $price = $_POST['ProdPrice']; // This will now accept 10.50
    $qty = $_POST['ProdQty'];
    $category = $_POST['Category'];
    
    $image = $_FILES['ProdImage']['name'];
    $target = "img/shop/" . basename($image);
$emp_id = $_SESSION['user_id']; 

    // Update your query to include EmpID
    $sql = "INSERT INTO product (ProdName, ProdPrice, ProdQty, Category, ProdImage, EmpID) 
            VALUES ('$name', '$price', '$qty', '$category', '$image', '$emp_id')";
    if ($conn->query($sql) === TRUE) {
        if (move_uploaded_file($_FILES['ProdImage']['tmp_name'], $target)) {
            echo "<script>alert('Product Added Successfully!'); window.location.href='manage_menu.php';</script>";
        } else {
            echo "<script>alert('Product saved but Image upload failed.'); window.location.href='manage_menu.php';</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="UTF-8">
    <title>Koffee Admin | Add Product</title>
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <style>
        .admin-card { background: #fff; padding: 40px; border-radius: 10px; box-shadow: 0 5px 25px rgba(0,0,0,0.05); max-width: 600px; margin: 50px auto; }
        .primary-btn { border: none; width: 100%; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="admin-card">
            <div class="section-title"><h2>Add New Product</h2></div>
            <form action="add_product.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Product Name</label>
                    <input type="text" name="ProdName" class="form-control" required>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group"><label>Price (RM)</label><input type="number" step="0.01" name="ProdPrice" class="form-control" required></div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group"><label>Stock</label><input type="number" name="ProdQty" class="form-control" required></div>
                    </div>
                </div>
                <div class="form-group">
                    <label>Category</label>
                    <select name="Category" class="form-control">
                        <option value="Meals">Meals</option>
                        <option value="Drinks">Drinks</option>
                        <option value="Desserts">Desserts</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Product Image</label>
                    <input type="file" name="ProdImage" class="form-control-file" required>
                </div>
                <button type="submit" name="save_product" class="primary-btn">Save Product</button>
            </form>
        </div>
    </div>
</body>
</html>