<?php 
session_start(); 
// Calculate cart data for the header
$cart_count = (isset($_SESSION['cart'])) ? array_sum($_SESSION['cart']) : 0;
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Koffee Cafe">
    <meta name="keywords" content="Cake, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Koffee | Register</title>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/flaticon.css" type="text/css">
    <link rel="stylesheet" href="css/barfiller.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<body>
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__inner">
                            <div class="header__top__left">
                                <a href="login.php" style="color: #111; font-weight: 600;">Sign in</a> 
                            </div>
                            <div class="header__logo">
                                <a href="./index.php"><img src="img/logo-cafe.png" alt="Koffee Logo"></a>
                            </div>
                            <div class="header__top__right">
                                <div class="header__top__right__cart">
                                    <a href="login.php" onclick="alert('Please login to view your cart');">
                                        <img src="img/icon/cart.png" alt=""> <span><?php echo $cart_count; ?></span>
                                    </a>
                                    <div class="cart__price">Items: <span><?php echo $cart_count; ?></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="canvas__open"><i class="fa fa-bars"></i></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="header__menu mobile-menu">
                        <ul>
                            <li><a href="./index.php">Home</a></li>
                            <li><a href="./about.php">About</a></li>
                            <li><a href="./menu.php">Menu</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

        <section class="contact spad">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-6 col-md-6">
                    <div class="contact__text">
                        <div class="section-title">
                            <span>Create Account</span>
                            <h2>Sign up now to start ordering!</h2>
                        </div>
                    </div>
                    <div class="contact__form">
                        <form action="register_process.php" method="POST">
                            <div class="row">
                                <div class="col-lg-12">
                                    <input type="text" name="CustName" placeholder="Username" required>
                                </div>
                                <div class="col-lg-12">
                                    <input type="number" name="CustPhone" placeholder="Phone Number" required>
                                </div>
                                <div class="col-lg-12">
                                    <input type="email" name="CustEmail" placeholder="Email Address" required>
                                </div>
                                <div class="col-lg-12">
                                    <input type="password" name="CustPassword" placeholder="Password" required>
                                </div>
                                <div class="col-lg-12">
                                    <input type="password" name="confirm_password" placeholder="Confirm Password" required>
                                </div>
                                <div class="col-lg-12">
                                    <input type="text" name="CustAddress" placeholder="Address" required>
                                </div>
                                <div class="col-lg-12 text-center">
                                    <p>Already have an account? <a href="login.php" style="color: #f08632; font-weight:600;">Login here</a></p>
                                    <button type="submit" name="register" class="site-btn">Register Now</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.barfiller.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>