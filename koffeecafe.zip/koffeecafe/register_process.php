<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include 'db_connect.php'; // Use the connection file we created earlier

if (isset($_POST['register'])) {
    // Collect and sanitize input data
    $name = mysqli_real_escape_string($conn, $_POST['CustName']);
    $phone = mysqli_real_escape_string($conn, $_POST['CustPhone']);
    $email = mysqli_real_escape_string($conn, $_POST['CustEmail']);
    $address = mysqli_real_escape_string($conn, $_POST['CustAddress']);
    
    // Security: In a real app, use password_hash(). For now, matching your ERD:
    $password = mysqli_real_escape_string($conn, $_POST['CustPassword']);

    // Check if email already exists
    $checkEmail = "SELECT * FROM customer WHERE CustEmail = '$email'";
    $result = $conn->query($checkEmail);

    if ($result->num_rows > 0) {
        echo "<script>alert('Email already registered!'); window.history.back();</script>";
    } else {
        // Insert into customer table based on your ERD columns
        $sql = "INSERT INTO customer (CustName, CustPhone, CustEmail, CustPassword, CustAddress) 
                VALUES ('$name', '$phone', '$email', '$password', '$address')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Registration successful! Please login.'); window.location='login.html';</script>";
        } else {
            echo "Error: " . $conn->error;
        }
    }
}
?>