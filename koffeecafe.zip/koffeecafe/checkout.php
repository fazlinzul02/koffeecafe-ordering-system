<?php 
session_start(); 
include 'db_connect.php';

/* REMOVED: The redirect logic that sends users back to menu.php */

// Handle Remove Item logic
if (isset($_GET['remove'])) {
    $remove_id = $_GET['remove'];
    unset($_SESSION['cart'][$remove_id]);
    header("Location: checkout.php");
    exit();
}

// Fetch logged-in user details
$cust_id = $_SESSION['user_id'] ?? 0;
$user_name = "";
$user_phone = "";

if ($cust_id > 0) {
    $user_query = "SELECT CustName, CustPhone FROM customer WHERE CustID = '$cust_id'";
    $user_result = $conn->query($user_query);
    if ($user_row = $user_result->fetch_assoc()) {
        $user_name = $user_row['CustName'];
        $user_phone = $user_row['CustPhone'];
    }
}
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Koffee | Checkout</title>

    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    
    <style>
        .remove-item { color: #b7b7b7; font-size: 14px; cursor: pointer; margin-left: 10px; transition: all 0.3s; }
        .remove-item:hover { color: #f08632; }
        .checkout__total__products li span { float: right; }
        /* Style for empty cart message */
        .empty-cart-msg { padding: 20px 0; color: #888; font-style: italic; text-align: center; }
    </style>
</head>

<body>
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__inner">
                            <div class="header__top__left">
                                <?php if(isset($_SESSION['user_name'])): ?>
                                    <span style="color: #111; font-weight: 600;">
                                        <?php echo ($_SESSION['role'] == 'employee') ? "Staff: " : "Welcome, "; ?>
                                        <?php echo $_SESSION['user_name']; ?>
                                    </span>
                                    <a href="logout.php" style="margin-left: 15px; color: #f08632;">Logout</a>
                                <?php else: ?>
                                    <a href="login.html" style="color: #111; font-weight: 600;">Sign in</a>
                                <?php endif; ?> 
                            </div>
                            <div class="header__logo">
                                <a href="index.php"><img src="img/logo-cafe.png" alt=""></a>
                            </div>
                            <div class="header__top__right">
                                <div class="header__top__right__cart">
                                    <?php $cart_count = isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>
                                    <a href="checkout.php"><img src="img/icon/cart.png" alt=""> <span><?php echo $cart_count; ?></span></a>
                                    <div class="cart__price">Items: <span><?php echo $cart_count; ?></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="header__menu mobile-menu">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="about.php">About</a></li>
                            <li><a href="menu.php">Menu</a></li>
                            <?php if(isset($_SESSION['user_id'])): ?>
                            <li><a href="my_orders.php">My Orders</a></li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <div class="breadcrumb-option">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="breadcrumb__text">
                        <h2>Checkout</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="checkout spad">
        <div class="container">
            <div class="checkout__form">
                <form action="place_order.php" method="POST" onsubmit="return checkCart()">
                    <div class="row">
                        <div class="col-lg-8 col-md-6">
                            <h6 class="checkout__title">Customer Details</h6>
                            <div class="checkout__input">
                                <p>Full Name</p>
                                <h5 style="margin-bottom: 20px; font-weight: 600; color: #111;"><?php echo $user_name; ?></h5>
                            </div>
                            <div class="checkout__input">
                                <p>Phone Number</p>
                                <h5 style="margin-bottom: 20px; font-weight: 600; color: #111;"><?php echo $user_phone; ?></h5>
                            </div>
                            <div class="checkout__input">
                                <p>Order Notes (Optional)</p>
                                <input type="text" name="notes" placeholder="Notes about your order...">
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-6">
                            <div class="checkout__order">
                                <h6 class="order__title">Your order</h6>
                                <div class="checkout__order__products">Product <span>Total</span></div>
                                <ul class="checkout__total__products">
                                    <?php 
                                    $total_price = 0;
                                    $count = 1;
                                    if(!empty($_SESSION['cart'])):
                                        foreach($_SESSION['cart'] as $id => $qty):
                                            $sql = "SELECT ProdName, ProdPrice FROM product WHERE ProdID = $id";
                                            $res = $conn->query($sql);
                                            if($row = $res->fetch_assoc()):
                                                $subtotal = $row['ProdPrice'] * $qty;
                                                $total_price += $subtotal;
                                    ?>
                                        <li>
                                            <samp><?php echo str_pad($count++, 2, "0", STR_PAD_LEFT); ?>.</samp> 
                                            <?php echo $row['ProdName']; ?> x<?php echo $qty; ?>
                                            <a href="checkout.php?remove=<?php echo $id; ?>" class="remove-item"><i class="fa fa-close"></i></a>
                                            <span>RM <?php echo number_format($subtotal, 2); ?></span>
                                        </li>
                                    <?php 
                                            endif;
                                        endforeach; 
                                    else: ?>
                                        <li class="empty-cart-msg">Your cart is currently empty.</li>
                                    <?php endif; ?>
                                </ul>

                                <ul class="checkout__total__all">
                                    <li>Total <span>RM <?php echo number_format($total_price, 2); ?></span></li>
                                </ul>
                                
                                <input type="hidden" name="total_amount" value="<?php echo $total_price; ?>">

                                <h6 class="checkout__title" style="border-bottom: none; margin-bottom: 10px; font-size: 16px;">Payment Method</h6>
                                
                                <div class="checkout__input__checkbox">
                                    <label for="cash">Cash <input type="radio" name="payment_method" id="cash" value="Cash" checked><span class="checkmark"></span></label>
                                </div>
                                <div class="checkout__input__checkbox">
                                    <label for="card">Credit / Debit Card <input type="radio" name="payment_method" id="card" value="Card"><span class="checkmark"></span></label>
                                </div>
                                <div class="checkout__input__checkbox">
                                    <label for="banking">Online Banking (FPX) <input type="radio" name="payment_method" id="banking" value="Online Banking"><span class="checkmark"></span></label>
                                </div>

                                <button type="submit" class="site-btn">PLACE ORDER</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
        // Prevent form submission if total is 0
        function checkCart() {
            var total = <?php echo $total_price; ?>;
            if (total <= 0) {
                alert("Your cart is empty! Please add items from the menu first.");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>