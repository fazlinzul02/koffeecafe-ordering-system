<?php
session_start();
include 'db_connect.php';

// Security check: Only employees allowed
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'employee') {
    header("Location: login.html");
    exit();
}

// SQL Query: GROUP BY OrderID so we only see one row per order
$sql = "SELECT 
            o.OrderID, 
            c.CustName, 
            o.OrderDate, 
            o.TotalAmount
        FROM `orders` o
        JOIN customer c ON o.CustID = c.CustID
        WHERE o.OrderStatus = 'Pending'
        GROUP BY o.OrderID
        ORDER BY o.OrderID DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Koffee Admin | Orders</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <style>
        .admin-card {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.05);
            margin-bottom: 50px;
        }
        .table thead th {
            background-color: #f08632;
            color: white;
            border: none;
        }
    </style>
</head>

<body>
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__logo">
            <a href="index.php"><img src="img/logo-cafe.png" alt=""></a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <div class="offcanvas__option">
            <ul>
                <li>Staff: <?php echo $_SESSION['user_name']; ?> <a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header__top__inner">
                            <div class="header__top__left">
                                <span style="color: #111; font-weight: 600;">Staff: <?php echo $_SESSION['user_name']; ?></span>
                                <a href="logout.php" style="margin-left: 15px; color: #f08632;">Logout</a>
                            </div>
                            <div class="header__logo">
                                <a href="admin_dashboard.php"><img src="img/logo-cafe.png" alt="Koffee Logo"></a>
                            </div>
                            <div class="header__top__right">
                                <div class="canvas__open"><i class="fa fa-bars"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="header__menu mobile-menu">
                        <ul>
                            <li class="active"><a href="admin_dashboard.php">Manage Orders</a></li>
                            <li><a href="manage_menu.php">Manage Menu</a></li>
                            <li><a href="menu.php">Preview Menu</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <section class="spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <span>Employee Portal</span>
                        <h2>Incoming Customer Orders</h2>
                    </div>
                    
                    <div class="admin-card">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Total Amount</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if ($result && $result->num_rows > 0): ?>
                                        <?php while($row = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td><strong>#<?php echo $row['OrderID']; ?></strong></td>
                                            <td><?php echo $row['CustName']; ?></td>
                                            <td>RM <?php echo number_format($row['TotalAmount'], 2); ?></td>
                                            <td><?php echo date('d M, h:i A', strtotime($row['OrderDate'])); ?></td>
                                            <td>
                                                <button class="btn btn-info btn-sm" onclick="viewItems(<?php echo $row['OrderID']; ?>)">
                                                    <i class="fa fa-list"></i> View Items
                                                </button>

                                                <a href="update_status.php?id=<?php echo $row['OrderID']; ?>&status=Completed" 
                                                   class="btn btn-success btn-sm">Mark Ready</a>
                                                
                                                <a href="delete_order.php?id=<?php echo $row['OrderID']; ?>" 
                                                   class="btn btn-outline-danger btn-sm" 
                                                   onclick="return confirm('Cancel this order?')">Cancel</a>
                                            </td>
                                        </tr>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <tr><td colspan="5" class="text-center">No pending orders to display.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="modal fade" id="orderModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header" style="background: #f08632; color: white;">
                    <h5 class="modal-title">Order Items</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body" id="modalBody">
                    <p class="text-center">Loading items...</p>
                </div>
            </div>
        </div>
    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/main.js"></script>

    <script>
    function viewItems(id) {
        $('#orderModal').modal('show');
        $.ajax({
            url: 'fetch_order_items.php',
            method: 'GET',
            data: { order_id: id },
            success: function(data) {
                $('#modalBody').html(data);
            }
        });
    }
    </script>
</body>
</html>